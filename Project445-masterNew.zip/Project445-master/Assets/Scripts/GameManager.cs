﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

	// Use this for initialization
	void Start ()
	{
		// Made some remote changes
		// More remote changes
	}
	
	// Update is called once per frame
	void Update ()
	{
		// Local change
	}
}
